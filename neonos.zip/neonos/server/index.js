import { createServer } from "http";
import { createBareServer } from "@tomphttp/bare-server-node";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;

const app = express();
const bareServer = createBareServer("/bare/");

// Serve the NeonOS frontend
app.use(express.static(path.join(__dirname, "../public")));

// Serve Scramjet proxy client assets
app.use(
  "/scramjet/",
  express.static(
    path.join(
      __dirname,
      "../node_modules/@mercuryworkshop/scramjet/dist"
    )
  )
);

// SPA fallback
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

const httpServer = createServer();

httpServer.on("request", (req, res) => {
  if (bareServer.shouldRoute(req)) {
    bareServer.routeRequest(req, res);
  } else {
    app(req, res);
  }
});

httpServer.on("upgrade", (req, socket, head) => {
  if (bareServer.shouldRoute(req)) {
    bareServer.routeUpgrade(req, socket, head);
  } else {
    socket.destroy();
  }
});

httpServer.listen(PORT, () => {
  console.log("");
  console.log("\x1b[32m  ███╗   ██╗███████╗ ██████╗ ███╗   ██╗ ██████╗ ███████╗\x1b[0m");
  console.log("\x1b[32m  ████╗  ██║██╔════╝██╔═══██╗████╗  ██║██╔═══██╗██╔════╝\x1b[0m");
  console.log("\x1b[32m  ██╔██╗ ██║█████╗  ██║   ██║██╔██╗ ██║██║   ██║███████╗\x1b[0m");
  console.log("\x1b[32m  ██║╚██╗██║██╔══╝  ██║   ██║██║╚██╗██║██║   ██║╚════██║\x1b[0m");
  console.log("\x1b[32m  ██║ ╚████║███████╗╚██████╔╝██║ ╚████║╚██████╔╝███████║\x1b[0m");
  console.log("\x1b[32m  ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚══════╝\x1b[0m");
  console.log("");
  console.log(`\x1b[32m  ► NeonOS running at http://localhost:${PORT}\x1b[0m`);
  console.log(`\x1b[32m  ► Bare proxy at     http://localhost:${PORT}/bare/\x1b[0m`);
  console.log(`\x1b[32m  ► Scramjet assets   http://localhost:${PORT}/scramjet/\x1b[0m`);
  console.log("");
});
