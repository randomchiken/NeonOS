# ◈ NeonOS

A minimal, hackable **Web Operating System** with a neon green terminal aesthetic.  
Browser powered by [Scramjet](https://github.com/MercuryWorkshop/scramjet) web proxy.

```
██╗   ██╗███████╗ ██████╗ ███╗   ██╗ ██████╗ ███████╗
████╗  ██║██╔════╝██╔═══██╗████╗  ██║██╔═══██╗██╔════╝
██╔██╗ ██║█████╗  ██║   ██║██╔██╗ ██║██║   ██║███████╗
██║╚██╗██║██╔══╝  ██║   ██║██║╚██╗██║██║   ██║╚════██║
██║ ╚████║███████╗╚██████╔╝██║ ╚████║╚██████╔╝███████║
╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚══════╝
```

## Quick Start

```bash
pnpm i && pnpm start
```

Open **http://localhost:3000**

## Requirements

- Node.js 18+
- pnpm

## Features

| App | Description |
|-----|-------------|
| 🌐 NeonBrowser | Scramjet-proxied browser with address bar |
| 📝 Notepad | Multi-instance text editor with word count |
| 🛒 App Store | Install future apps (expandable) |
| ⚙️ Settings | Theme toggles, proxy status, network latency |
| ℹ️ About | System info |

**Window manager:**
- Drag, resize, minimize, maximize
- Z-ordering, taskbar integration
- Multi-instance windows

**Aesthetic:**
- Neon green `#39ff14` on pure black
- CRT scanline overlay
- Glow/shadow effects throughout
- Orbitron + Share Tech Mono fonts
- Animated boot sequence

## How the Proxy Works

1. **Express** serves the NeonOS frontend from `public/`
2. **Bare Server** (`@tomphttp/bare-server-node`) handles proxy requests at `/bare/`
3. **Scramjet** client-side assets are served at `/scramjet/`
4. When you navigate in NeonBrowser, the URL is routed through Scramjet → Bare → internet

## Project Structure

```
neonos/
├── public/
│   └── index.html      # Entire NeonOS frontend (single file)
├── server/
│   └── index.js        # Express + Bare server
├── package.json
└── README.md
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT`   | `3000`  | HTTP port   |

## Adding Apps

In `public/index.html`, add a function:

```js
function openMyApp() {
  createWin({
    id: 'myapp',
    title: 'My App',
    icon: '🎮',
    w: 600, h: 400,
    html: `<div style="padding:16px;color:var(--neon)">// Hello, NeonOS</div>`
  });
}
```

Then add a desktop icon and a Neo Menu entry.

## License

MIT
